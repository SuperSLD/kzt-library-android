from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
import torch
# Загрузка модели
MODEL_NAME = "Vikhrmodels/Vikhr-7B-instruct_0.2"
model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    load_in_8bit=True,
    torch_dtype=torch.float16,
    device_map="auto"
)
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=False)
generation_config = GenerationConfig.from_pretrained(MODEL_NAME)
generation_config.max_length = 256
generation_config.top_p = 0.9
generation_config.top_k = 30
generation_config.do_sample = True

class Conversation:
    def __init__(self, message_template="<s>{role}\n{content}</s>\n", system_prompt="Ты — Вихрь, русскоязычный автоматический ассистент. Ты разговариваешь с людьми и помогаешь им."):
        self.message_template = message_template
        self.messages = [{"role": "system", "content": system_prompt}]

    def add_user_message(self, message):
        self.messages.append({"role": "user", "content": message})

    def get_prompt(self, tokenizer):
        final_text = ""
        for message in self.messages:
            message_text = self.message_template.format(**message)
            final_text += message_text
        final_text += 'bot'
        return final_text.strip()

def generate(model, tokenizer, prompt, generation_config):
    data = tokenizer(prompt, return_tensors="pt")
    data = {k: v.to(model.device) for k, v in data.items()}
    output_ids = model.generate(**data, generation_config=generation_config)[0]
    output_ids = output_ids[len(data["input_ids"][0]):]
    output = tokenizer.decode(output_ids, skip_special_tokens=True)
    return output.strip()

def generate_book_description(title):
    conversation = Conversation()
    prompt = f"Напишите описание для книги с названием '{title}'."
    conversation.add_user_message(prompt)
    final_prompt = conversation.get_prompt(tokenizer)
    description = generate(model, tokenizer, final_prompt, generation_config)
    return description
