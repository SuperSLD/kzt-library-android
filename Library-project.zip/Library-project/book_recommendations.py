
from openai import OpenAI

class BookRecommendations:
    def __init__(self, api_key, model_name):
        self.client = OpenAI(api_key="API_KEY", base_url="https://api.vsegpt.ru/v1")
        self.model_name = model_name

    def recommend_books(self, user_favorite_books):
        books = ['Евгений Онегин', 'Отцы и дети', 'Тихий Дон', 'Анна Каренина', 'Идиот', 'Мертвые души', 'Герой нашего времени', 'Обломов', 'Капитанская дочка', 'Вишневый сад', 'Горе от ума', 'Машина времени', 'Война миров', 'Три сестры', 'Братья Карамазовы', 'Золотой телёнок', 'Собачье сердце', 'Мы', 'Двенадцать стульев', 'Джейн Эйр', 'Маленькие женщины', 'Хоббит', 'Властелин Колец', 'Дюна', 'Грозовой перевал', 'Портрет Дориана Грея', 'Алиса в стране чудес']
        recommendations = []
        for book in user_favorite_books:
            prompt = f"Отдай список из 2 книг и авторов, похожих на '{book}' из {books}"
            messages = [{"role": "user", "content": prompt}]
            
            response_big = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                temperature=0.7,
                n=1,
                max_tokens=3000,
                extra_headers={"X-Title": "Book Recommendations"}
            )
            
            response = response_big.choices[0].message.content
            recommendations.append({
                "book": book,
                "recommendations": response
            })
        return recommendations
