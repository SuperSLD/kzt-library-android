import json
import os
import requests
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig, BitsAndBytesConfig
import torch
from book_search import BookSearch
from book_recommendations import BookRecommendations


# Настройки модели
MODEL_NAME = "Vikhrmodels/Vikhr-7B-instruct_0.2"
quantization_config = BitsAndBytesConfig(load_in_8bit_fp32_cpu_offload=True)

model = AutoModelForCausalLM.from_pretrained(
    MODEL_NAME,
    quantization_config=quantization_config,
    torch_dtype=torch.float16,
    device_map="auto"
)
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME, use_fast=False)
generation_config = GenerationConfig.from_pretrained(MODEL_NAME)
generation_config.max_length = 256
generation_config.top_p = 0.9
generation_config.top_k = 30
generation_config.do_sample = True

# Чтение списка книг из JSON-файла
def load_books_from_json(file_path):
    """Загружает список книг из JSON-файла."""
    with open(file_path, 'r', encoding='utf-8') as f:
        books = json.load(f)
    return books

# Основная логика для обработки списка книг
def process_books(file_path):
    list_books = []
    books = load_books_from_json(file_path)
    for book_title in books:
        # Поиск книги
        book_search = BookSearch(book_title, model)
        book_search.set_tokenizer_and_config(tokenizer, generation_config)
        book_search.search_book()
        book_info = book_search.get_info()

        if isinstance(book_info, dict):
            # Форматирование данных для отправки на сервер
            book_data = {
                "title": book_info.get('название', ''),
                "description": book_info.get('описание', ''),
                "rating": round(float(book_info['рейтинг']), 1) if book_info.get('рейтинг') and book_info['рейтинг'] != "Рейтинг недоступен" else -1.0,
                "cover": book_info.get('обложка', ''),
                "author": book_info.get('автор', '')
            }
            list_books.append(book_data)
        else:
            print(f"Книга '{book_title}' не найдена.")
    return list_books

# Отправка информации о книгах на сервер
def send_book_info(list_books, url_books):
    response = requests.post(url_books, json=list_books)
    print(f"Ответ сервера на отправку книг: {response.text}")

# Отправка рекомендаций по книгам на другой сервер
def send_recommendations(recommendations, url_recommend):
    response = requests.post(url_recommend, json=recommendations)
    print(f"Ответ сервера на рекомендации: {response.text}")

# Генерация и отправка рекомендаций
def generate_recommendations(user_favorite_books):
    recommender = BookRecommendations(model, tokenizer, generation_config)
    recommendations = recommender.recommend_books(user_favorite_books)
    # send_recommendations(recommendations)
    return recommendations

# Основной блок программы
if __name__ == "__main__":
    # Чтение списка книг из JSON-файла и отправка информации на сервер
    json_file_path = os.getenv('BOOKS_LIST_PATH')
    url_books = os.getenv('URL_BOOKS')
    url_recommend = os.getenv('URL_RECOMMEND')
    list_books = process_books(json_file_path)
    
    # Сохранение обработанных данных в JSON-файл
    with open('processed_books_data.json', 'w', encoding='utf-8') as f:
        json.dump(list_books, f, ensure_ascii=False, indent=4)

    # Отправка информации о книгах на сервер
    send_book_info(list_books)

    # Рекомендации книг для пользователя
    user_favorite_books = [
        "Война и мир", "Преступление и наказание", "Мастер и Маргарита"
    ]
    recommendations = generate_recommendations(user_favorite_books)
    print(recommendations)
