import requests
import re
from conversation import generate_book_description, Conversation, generate

class BookSearch:
    def __init__(self, title, model):
        self.title = title
        self.model = model
        self.tokenizer = None
        self.generation_config = None
        self.book_info = None

    def set_tokenizer_and_config(self, tokenizer, generation_config):
        self.tokenizer = tokenizer
        self.generation_config = generation_config

    def search_book(self):
        search_url = f"https://openlibrary.org/search.json?title={self.title}"
        response = requests.get(search_url)
        if response.status_code == 200:
            data = response.json()
            if data['numFound'] > 0:
                book_data = data['docs'][0]
                # Попытка найти описание в нескольких полях
                description = (
                    book_data.get('first_sentence', [''])[0] or
                    book_data.get('subtitle', '') or
                    book_data.get('notes', '')
                )
                
                # Очистка текста от специальных символов
                cleaned_description = self.clean_text(description)
                
                # Генерация описания, если оно не найдено
                generated_description = generate_book_description(self.title) if not cleaned_description else cleaned_description
                
                self.book_info = {
                    "название": book_data.get("title"),
                    "автор": ", ".join(book_data.get("author_name", [])),
                    "описание": generated_description,
                    "обложка": self.get_book_cover(book_data.get("isbn", [])[0]) if "isbn" in book_data else "https://grizly.club/uploads/posts/2022-12/1670124993_grizly-club-p-shablon-oblozhka-knigi-17.jpg",
                    "рейтинг": self.get_book_rating(book_data.get("key")) if "key" in book_data else ""
                }
            else:
                self.book_info = "Книг с таким названием не найдено."
        else:
            self.book_info = f"Ошибка: {response.status_code}"

    def get_book_cover(self, isbn):
        cover_url = f"https://covers.openlibrary.org/b/isbn/{isbn}-L.jpg"
        response = requests.get(cover_url)
        return cover_url if response.status_code == 200 else "https://grizly.club/uploads/posts/2022-12/1670124993_grizly-club-p-shablon-oblozhka-knigi-17.jpg"

    def get_book_rating(self, work_key):
        rating_url = f"https://openlibrary.org{work_key}/ratings.json"
        response = requests.get(rating_url)
        if response.status_code == 200:
            data = response.json()
            average_rating = data.get("summary", {}).get("average")
            return round(float(average_rating), 2) if average_rating is not None else -1.0
        return -1.0

    def clean_text(self, text):
        text = re.sub(r'[^\w\s]', '', text)  #
        text = re.sub(r'\s+', ' ', text)     
        text = text.strip()                  
        return text

    def get_info(self):
        return self.book_info if self.book_info else "Книга не найдена."
